export function monitorStats(input, output) {
  return {
    inputTokens: input.length,
    outputTokens: output.length,
    timestamp: Date.now()
  };
}
