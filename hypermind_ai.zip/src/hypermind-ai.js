export function analyzeMessage(message, memory) {
  return {
    systemPrompt: "Você é uma IA avançada que responde com precisão e clareza."
  };
}
