import fs from 'fs';

const path = './models/memory.json';

export function loadMemory() {
  if (!fs.existsSync(path)) return { conversations: [] };
  return JSON.parse(fs.readFileSync(path, 'utf8'));
}

export function saveMemory(memory) {
  fs.writeFileSync(path, JSON.stringify(memory, null, 2));
}
